#!/usr/bin/env python

# Transform input messages on stdin (Volansys format)
# to output messsages on stdout (Medium One format)

# Press Control-C to terminate

from __future__ import print_function
import sys
import json
import time
import codecs
import argparse
import traceback

parser = argparse.ArgumentParser()
parser.add_argument("--debug", action="store_true", default=False)
args = parser.parse_args()

stop = False

# Sensor data values of interest

temp = None
humid = None
light = None
temp_last = None
humid_last = None
light_last = None
last_output_time = 0 

try:
  while not stop:
    line = sys.stdin.readline().strip()
    if line.find('Pub_VTBR_') != -1 and line.find('{"Ctype":42') != -1:
      try:
        s = line.find('{')
        if s != -1:
          p = json.loads(line[s:])
          if 'payload' in p:
            decoded_payload = codecs.decode(p['payload'][:-2], 'hex')
            x = decoded_payload.find(b'{"uri":')
            if x != -1:
              extract_payload = json.loads(decoded_payload[x:])
              if extract_payload['uri'] == '/temp_get':
                temp = float(extract_payload['data'][0]['temp'])
              elif extract_payload['uri'] == '/humid_get':
                humid = float(extract_payload['data'][0]['humid'])
              elif extract_payload['uri'] == '/light_get':
                light = float(extract_payload['data'][0]['light'])
              if temp != None and humid != None and light != None:
                time_now = time.time()
                if temp != temp_last or humid != humid_last or light != light_last or (time_now - last_output_time) > 10:
                  output = {
                    'event_data': {
                      'timestamp': int(time.time()),
                      'temp': temp,
                      'humid': humid,
                      'light': light 
                    }
                  }
                  print(json.dumps(output))
                  sys.stdout.flush()
                  if args.debug:
                    print(json.dumps(output), file=sys.stderr)
                  last_output_time = time_now
                temp_last = temp
                humid_last = humid
                light_last = light
                temp = None
                humid = None
                light = None
      except KeyboardInterrupt:
        stop = True
        break
      except:
        traceback.print_exc(file=sys.stderr)
        pass
except KeyboardInterrupt:
  stop = True

