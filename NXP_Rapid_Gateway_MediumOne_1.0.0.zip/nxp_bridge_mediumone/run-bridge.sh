#!/bin/bash

#### NXP Modular Gateway ####
GATEWAY_ID=000000000000

#### Volansys cloud ####
V_HOSTNAME=volansys.noip.me
#V_HOSTNAME=54.89.105.58
V_PORT=1883
V_USERNAME=volansys
V_PASSWORD=volansys
V_TOPIC=Pub_VTBR_$GATEWAY_ID

#### Medium One cloud ####
M_HOSTNAME=mqtt.mediumone.com
M_PORT=61619
#### mydevice ####
M_USERNAME=XXXXXXXXXXX/YYYYYYYYYYY
M_PASSWORD=XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX/YYYYYYYY
M_TOPIC=0/XXXXXXXXXXX/YYYYYYYYYYY/mydevice

#########################################################
# Receive from Volansys and transmit to Medium One
#########################################################

mosquitto_sub -h "$V_HOSTNAME" -p $V_PORT -u "$V_USERNAME" -P "$V_PASSWORD" -t "$V_TOPIC" -v | python v2m1.py --debug | mosquitto_pub -h "$M_HOSTNAME" -p $M_PORT -u "$M_USERNAME" -P "$M_PASSWORD" -t "$M_TOPIC" -l -d

